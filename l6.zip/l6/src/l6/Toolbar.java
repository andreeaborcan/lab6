/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l6;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

/**
 *
 * @author ada
 */
public class Toolbar extends JPanel{
    JLabel dimensiune=new JLabel();
    JLabel nr_laturi=new JLabel();
    JSpinner dim = new JSpinner(new SpinnerNumberModel(10,1,20,1));
    JSpinner nr_l = new JSpinner(new SpinnerNumberModel(5, 3, 6, 1));
    JButton add=new JButton();
    
    
    public Toolbar(){
     setLayout(new GridLayout(3, 2));
        dimensiune.setText("DIMENSIUNE: ");
        add(dimensiune);
        
       add(dim);
         nr_laturi.setText("NR. LATURI: ");
        add(nr_laturi);
        
        add(nr_l);
        //setBackground(Color.gray);
        add.setText("ADD");
        add(add);
        this.setSize(new Dimension(200,200));
    
    }
}
