/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l6;

import java.awt.BorderLayout;
import java.awt.*;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.io.IOException;
import javax.swing.*;

/**
 *
 * @author ada
 */
public class DrawingFrame extends JFrame {

    private int nbSides;
    private int nbShapes;
    private int stroke;
    Toolbar toolbar;
    JButton Draw = new JButton();
    ControlPanel controlPanel;
    Canvas canvas;
    public DrawingFrame(String title) throws IOException {
        super(title);

        setSize(500, 700);
        this.setLayout(new GridLayout(3, 1));

        
       
        toolbar = new Toolbar();
        this.add(toolbar);
        canvas= new Canvas();
        this.add(canvas);
        controlPanel = new ControlPanel();
        this.add(controlPanel);
        this.setLocationRelativeTo(null);
        
        
        
        
        
        
        this.setVisible(true);
        
        
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}

