/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l6;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ImageObserver;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.RenderableImage;
import java.io.File;
import java.io.IOException;
import java.text.AttributedCharacterIterator;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author ada
 */
public final class Canvas extends JPanel {
 ImageIcon ii;
    public Canvas() throws IOException {
        //ImageIcon p = new ImageIcon();
        //BufferedImage img = new BufferedImage(100, 200, BufferedImage.TYPE_INT_ARGB); //ImageIO.read(new File("/home/ada/Desktop/ada3.png"));
        //JLabel lbl = new JLabel();
        //p.setImage(img);
        //lbl.setIcon(p);
        //add(lbl);
        //Graphics2D g=img.createGraphics(); 
        //drawCenteredCircle(g, 1, 1, 1);
        
                
              
   /* this.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {                
           // drawShapeAt(e.getX(), e.getY());    
           // paintComponent(g);     
            //paint(g);
        }
    });*/
    }
    public void drawShapeAt(int x, int y) {
        Graphics graphics;
                
        Random rand = new Random();
       //graphics.setColor(new Color(rand.nextInt(0xFFFFFF)));
      // graphics.fill(new RegularPolygon(x, y, radius, sides));
    }

 @Override
    public void paint(Graphics g){
          g.drawOval(100, 100, 60, 60); //FOR CIRCLE
          g.drawRect(80, 30, 20, 20); // FOR SQUARE
          g.drawRect(20, 100, 100, 20); // FOR RECT
     }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d;
        g2d = (Graphics2D) g;
    }public void drawCenteredCircle(Graphics2D g, int x, int y, int r) {
  x = x-(r/2);
  y = y-(r/2);
  g.fillOval(x,y,r,r);
}

    

}

